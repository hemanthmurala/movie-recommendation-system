module.exports = {
    mongoURI:process.env.MONGO_URI,
    mail:process.env.MAIL,
    Oauth_Client_Id: process.env.Oauth_Client_Id,
    Oauth_Client_Secret: process.env.Oauth_Client_Secret,
    Oauth_Refresh_Token: process.env.Oauth_Refresh_Token ,
    Oauth_Access_Token: process.env.Oauth_Access_Token,
    Oauth_redirect_url: process.env.Oauth_redirect_url
}