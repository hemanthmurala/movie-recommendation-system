module.exports = {
    apiIMDB: 'f29f2233f1aa782b0f0dc8d6d9493c64'
};